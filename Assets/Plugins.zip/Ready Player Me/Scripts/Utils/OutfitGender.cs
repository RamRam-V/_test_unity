﻿using System.ComponentModel;

namespace ReadyPlayerMe
{
    public enum OutfitGender
    {
        [Description("masculine")]
        Masculine,
        [Description("feminine")]
        Feminine
    }
}
