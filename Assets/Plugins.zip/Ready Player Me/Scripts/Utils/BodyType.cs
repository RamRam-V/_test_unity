﻿using System.ComponentModel;

namespace ReadyPlayerMe
{
    public enum BodyType
    {
        [Description("fullbody")]
        Fullbody,
        [Description("halfbody")]
        Halfbody
    }
}

